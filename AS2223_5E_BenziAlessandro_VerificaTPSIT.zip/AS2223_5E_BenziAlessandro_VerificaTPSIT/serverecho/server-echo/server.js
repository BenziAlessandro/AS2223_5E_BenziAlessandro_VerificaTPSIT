const WebSocket = require("ws"); // per includere un modulo usiamo
const PORT = 5000; 
const wsServer = new WebSocket.Server({port: PORT}); 

console.log("Il Server e attivo e aspetta pacchetti sulla porta " + wsServer.options.port);

wsServer.on('connection', function (socket) {
    ws.on('message', (message) => {
        if (message === 'moltiplica') {
            operation = 'multiply';
            wsServer.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send('Il Server ora moltiplichera ogni numero ricevuto');
                    socket.send(Calcola(message));
                }
            });
        } else if (message === 'raddoppia') {
            operation = 'double';
            wsServer.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send('Il Server ora raddopiera ogni numero ricevuto');
                    socket.send(Calcola(message));
                }
            });
        } else if (message === 'fattoriale') {
            operation = 'factorial';
            wsServer.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send('Il Server ora fattorializzera ogni numero ricevuto');
                    socket.send(Calcola(message));
                }
            });
        }});
    });

    function Calcola(stringa) {
        var _op = operation;
        let numero = parseInt(stringa);
        switch (_op) {
            case "multiply":
                return numero*numero;
            case "double":
                return numero*2;
            case "factorial":
                return Fattoriale(numero);
            default:
                break;
        }
    }

    function Fattoriale(numero){
        if (numero === 0) {
            return 1;
        }
        return numero * factorial(numero - 1);
    }